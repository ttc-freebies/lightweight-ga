<?php
/**
 * @copyright   Copyright (C) 2020 Dimitrios Grammatikogiannis. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

$anonymizedIp = boolval($params->get('anonymized-ip', 1)) === true ? 'true' : 'false';
$colorDepth = boolval($params->get('color-depth', 1)) === true ? 'true' : 'false';
$characterSet = boolval( $params->get('character-set', 1)) === true ? 'true' : 'false';
$screenSize = boolval($params->get('screen-size', 1)) === true ? 'true' : 'false';
$language = boolval($params->get('language', 1)) === true ? 'true' : 'false';
$siteCodeGA = (string) $params->get('site-code-ga', 'XX-XXXXXXXXX-X');
$onEvent = boolval($params->get('onevent', 0));
$eventName = (string) $params->get('eventname', 'DOMContentLoaded');

if ($siteCodeGA === 'XX-XXXXXXXXX-X') {
  return;
}

$scriptContent = <<<JS
!function(){"use strict";var e,t,o,n,i,a,c,r,d,s;e=window,t={anonymizeIp:$anonymizedIp,colorDepth:$colorDepth,characterSet:$characterSet,screenSize:$screenSize,language:$language},o=e.history,n=document,i=navigator||{},a=localStorage,c=encodeURIComponent,r=o.pushState,d=function(){return a.cid||(a.cid=Math.random().toString(36)),a.cid},s=function(o,a,r,s,l,u,p){var v="https://www.google-analytics.com/collect",h=function(e){var t=[];for(var o in e)e.hasOwnProperty(o)&&void 0!==e[o]&&t.push(c(o)+"="+c(e[o]));return t.join("&")}({v:"1",ds:"web",aip:t.anonymizeIp?1:void 0,tid:"$siteCodeGA",cid:d(),t:o||"pageview",sd:t.colorDepth&&screen.colorDepth?"".concat(screen.colorDepth,"-bits"):void 0,dr:n.referrer||void 0,dt:n.title,dl:n.location.origin+n.location.pathname+n.location.search,ul:t.language?(i.language||"").toLowerCase():void 0,de:t.characterSet?n.characterSet:void 0,sr:t.screenSize?"".concat((e.screen||{}).width,"x").concat((e.screen||{}).height):void 0,vp:t.screenSize&&e.visualViewport?"".concat((e.visualViewport||{}).width,"x").concat((e.visualViewport||{}).height):void 0,ec:a||void 0,ea:r||void 0,el:s||void 0,ev:l||void 0,exd:u||void 0,exf:void 0!==p&&0==!!p?0:void 0});if(i.sendBeacon)i.sendBeacon(v,h);else{var g=new XMLHttpRequest;g.open("POST",v,!0),g.send(h)}},o.pushState=function(e){return"function"==typeof o.onpushstate&&o.onpushstate({state:e}),setTimeout(s,t.delay||10),r.apply(o,arguments)},s(),e.ma={trackEvent:function(e,t,o,n){return s("event",e,t,o,n)},trackException:function(e,t){return s("exception",null,null,null,null,e,t)}}}();
JS;

if ($onEvent) { 
  $scriptContent = 'document.addEventListener("' . $eventName . '",function(){' . $scriptContent . '});';
}

echo '<script data-joomla-reposition="false">' . $scriptContent . '</script>';
